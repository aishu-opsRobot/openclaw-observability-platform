# BOOTSTRAP.md - opsRobot Agent 启动契约

> **Version:** v4.3
> **Last Updated:** 2026-05-11
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

> **ORCHESTRATOR_WS**：Orchestrator 工作空间路径
> - Linux/macOS：`~/.openclaw/sre`
> - Windows：`%USERPROFILE%\.openclaw\sre`
> - 可通过环境变量 `OPENCLAW_WS` 覆盖

---

## I. 定位

opsRobot Agent 启动契约，定义每次会话启动时必须完成的预检步骤。

---

## II. 启动预检清单

每次新会话启动时，必须按以下顺序完成预检：

### 1. 读取核心文档

- `IDENTITY.md` — 身份定义（职责/边界/能力）
- `AGENTS.md` — 运行手册（推送格式/决策节点/检查清单）
- `PLAYBOOK.md` — 执行手册（Pipeline 流程/task 模板）
- `templates/stage5_final_content.json` — Stage 5 最终报告模板（Orchestrator 生成前必须读取）

### 2. 确认 workspace 目录存在

```
mkdir -p {ORCHESTRATOR_WS}/artifacts/
mkdir -p {ORCHESTRATOR_WS}/templates/
mkdir -p {ORCHESTRATOR_WS}/memory/template_errors/
```

> workspace_root = git rev-parse --show-toplevel（失败时回退 pwd），禁止写死路径。

### 2.3 Workspace 安全约束

- 用户输入不直接拼接入 system prompt（防提示词注入）
- 删除/覆盖操作必须提供回滚路径
- 高危操作（rm -rf / destroy / 权限提升）强制二次确认

---

## III. Stage 0 执行规则

Stage 0 是强制性第一步，不得跳过，不得与其他阶段合并。

### incident_id 锁定

- 格式：`SRE-{ts_ms}-{rand6}`
- ts_ms：用户输入**分析时间**（Orchestrator 收到请求的 UTC 毫秒时间），不是数据 time_window
- 生成 6 位 Base36 随机后缀：`cat /dev/urandom | tr -dc '0-9A-Z' | fold -w 6 | head -n 1`
- 示例：`SRE-1743154200000-A7K9Q2`
- 内部标记：`incident_id: SRE-{ts}-{suffix} — 已锁定，禁止修改`
- 禁止将此标记输出给用户

### 推送流程

1. 推送意图识别（独立消息）
2. 推送任务规划（独立消息）
3. 输出固定尾缀：`▶ 即将调用 "感知子智能体" 进行环境感知...`（用户可见）
4. **立即执行** `sessions_spawn(agentId="sre-perception", cwd="{ORCHESTRATOR_WS}")`，**不带 sessions_yield**，同一 turn 结束

> ⚠️ 步骤 3 与步骤 4 必须紧邻，中间禁止插入任何内容。

### 禁止行为

- 未输出意图识别就调用 sessions_spawn
- 意图识别与任务规划合并为一条消息推送
- 重新生成已锁定的 incident_id
- incident_id 锁定标记输出给用户

---

## IV. 版本变更记录

- **v4.3**（2026-05-11）：启动预检清单新增 memory/template_errors/ 目录创建
- **v4.2**（2026-05-11）：启动预检清单新增 templates/stage5_final_content.json 读取要求
- **v4.1**（2026-05-11）：重构
