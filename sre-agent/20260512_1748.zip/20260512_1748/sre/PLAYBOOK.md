# PLAYBOOK.md - opsRobot Agent 执行手册

> **Version:** v4.3
> **Last Updated:** 2026-05-11
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

> **ORCHESTRATOR_WS**：Orchestrator 工作空间路径
> - Linux/macOS：`~/.openclaw/sre`
> - Windows：`%USERPROFILE%\.openclaw\sre`
> - 可通过环境变量 `OPENCLAW_WS` 覆盖

---

## I. 定位

opsRobot Agent 执行手册，定义 Pipeline 执行流程、task 模板格式规范、快速参考。

---

## II. Pipeline 执行流

### 核心调用规则

#### sessions_spawn 规则（强制）

每个阶段完成后，**直接调用**下一阶段的 `sessions_spawn`，**不带 sessions_yield**，在同一 turn 内完成。

```
Stage N 报告推送
   ↓
sessions_spawn(agentId="sre-{next_stage}", ...)
   ↓（同一 turn 结束，Orchestrator yield）
```

| 当前阶段 | 下一阶段 | sessions_spawn 调用 |
|---------|---------|-------------------|
| Stage 0（意图识别+任务规划） | Stage 1 | 1. 输出固定尾缀文字  2. `sessions_spawn(agentId="sre-perception", cwd="{ORCHESTRATOR_WS}")`，同一 turn 结束 |
| Stage 1（环境感知） | Stage 2 | `sessions_spawn(agentId="sre-analysis", ...)` |
| Stage 2（异常分析） | Stage 3 | `sessions_spawn(agentId="sre-reasoning", ...)` |
| Stage 3（根因推理） | Stage 4 | `sessions_spawn(agentId="sre-execution", ...)` |
| Stage 4（行动建议） | Stage 5 | `sessions_spawn` 不适用，直接推送 WAITING_FOR_APPROVAL |

**cwd 统一指定**：`sessions_spawn(..., cwd="{ORCHESTRATOR_WS}")`

#### sessions_yield 规则（强制）

每个 Stage 只调用**一次** `sessions_yield`，只在等待子智能体完成时调用，**不在阶段报告之间调用**。

**正确流程**：
```
sessions_spawn(agentId="sre-perception", ...)
sessions_yield()  ← 等待感知子智能体完成
   ↓
收到 subagent_announce 完成事件
   ↓
Orchestrator 提取 JSON → 写盘 → 推送 Stage 1 报告
   ↓
sessions_spawn(agentId="sre-analysis", ...)  ← 报告推送后直接 spawn，不 yield
   ↓ ← 延迟
sessions_yield()  ← 等待分析子智能体完成
   ↓
收到 subagent_announce 完成事件
   ↓
Orchestrator 提取 JSON → 写盘 → 推送 Stage 2 报告
   ↓
sessions_spawn(agentId="sre-reasoning", ...)
sessions_yield()  ← 等待推理子智能体完成
   ↓
...
```

**禁止场景**：
- 阶段报告推送完成后调用 `sessions_yield`（应直接 spawn 下一阶段）
- 在 `sessions_spawn` 前调用 `sessions_yield`（禁止反向调用）
- 在同一 Stage 内多次调用 `sessions_yield`（每个 Stage 只 yield 一次）
- 跳过 Stage 直接 yield（sessions_yield 前必须有对应的 sessions_spawn）

### 完整流程图

```
用户请求 → Stage 0（意图识别 + 任务规划）
    │
    ├── 用户已提供数据 → Stage 1（sre-perception 验证/标准化）
    │
    └── 用户未提供数据 → Stage 1（sre-perception 采集数据）
                            │
                            ├── 充分 → Stage 2
                            ├── 不足 → WAITING_FOR_DATA_SUPPLEMENT
                            └── 失败 → 最终报告
                                ↓
                        Stage 2（sre-analysis）
                            │
                            ├── success → Stage 3
                            └── failure → 最终报告
                                ↓
                        Stage 3（sre-reasoning）
                            │
                            ├── success → Stage 4
                            └── failure → 最终报告
                                ↓
                        Stage 4（sre-execution）
                            │
                            └── WAITING_FOR_APPROVAL
                                │
                                ├── 1 approve → Stage 5
                                ├── 2 cancel → 最终报告（EXECUTION_REJECTED）
                                ├── 3 reanalyze → 返回 Stage 2
                                └── 超时 → 最终报告
                                    ↓
                            Stage 5（Orchestrator 生成最终报告）
                                    ↓
                                最终报告
```

### 数据充分性判断

| 评估结果 | 说明 |
|---------|------|
| `sufficient` | 核心字段有支撑证据，置信度高 → 自动进入 Stage 2 |
| `insufficient` | 存在数据缺口，置信度中-低 → 暂停，输出 `WAITING_FOR_DATA_SUPPLEMENT` |
| `failed` | 核心字段缺失或采集失败 → 阻断，要求用户提供更多信息 |

---

## III. task 模板格式规范

### 调用规则

- **cwd**：`sessions_spawn(agentId="sre-*", cwd="{ORCHESTRATOR_WS}")`
- **绝对路径**：证据支撑 JSON 路径必须使用绝对路径，禁止相对路径

### 格式约定

- **Schema 读取**：生成任何 JSON 前，必须先读取 templates/ 下对应类型模板
- **数据缺失降级**：`{ "type": "<type>", "error_reason": "<原因>", "retry_suggestion": "<建议>" }`

### 各阶段 task 模板

> workspace_root = git rev-parse --show-toplevel（失败时回退 pwd），禁止写死路径。

#### Stage 1 — sre-perception（环境感知）

```
【角色】sre-perception 智能体，负责采集/验证系统的事实数据并标准化。

【前置输入】用户请求（自然语言 or 已提供数据）

【核心职责】
1. 数据采集：采集指标 / 日志 / 告警 / 拓扑 / 链路数据
2. 数据验证：验证 fact_sheet 完整性 / 补全缺失 / 标准化格式
3. 构建 fact_sheet（含 timeline / affected_nodes / alerts / metrics_summary / logs_summary / data_gaps / sufficiency）
4. 评估数据充分性（sufficient / insufficient / failed）

【Schema 引用】templates/stage1_*.json

【输入】incident_id / service / symptom / time_window / environment / metric_keys / log_keywords / alert_names / related_services / trace_id（可选）/ user_fact_sheet（用户提供时）

【输出路径】artifacts/{incident_id}/{incident_id}_stage1_*.json

【历史错误预防（来自 memory）- 强制】
请先执行 memory_search 查询 stage1 相关历史模板错误：
- 查询范围：memory/template_errors/ 目录
- 查询关键词：stage1, {incident_id}
- 无论查询结果是否为空，都必须在 task prompt 中保留本段落；
  - 若查到错误记录，将 prevention_hint 内容追加到【预防提示】；
  - 若查不到任何错误，写入：「未发现相关历史模板错误」
【预防提示】：{Orchestrator 在 spawn 前通过 memory_search 检索 stage1 相关错误，提取 prevention_hint 注入此处。若无历史错误则本段落为"未发现相关历史模板错误"}

【第二步：模板结构确认（强制）】
在生成任何 JSON 内容前，先回答以下问题（不得跳过，不得乱答）：
1. stage1_metrics_trend 的根字段是 metrics_series 还是 data_points？
2. stage1_logs_distribution 的 count_by_level 每项是几元数组？
3. stage1_topology_map 的 nodes 必须有哪些字段？（列举）
4. stage1_topology_map 的 edges 中是否允许有 type 字段？
5. stage1_trace_flamegraph 的 trace_root 中是否有 span_id 字段？它和 trace_id 是同一个吗？
6. stage1_perception_content 的 affected_nodes[].type 可选值有哪些？（列举）
若以上问题回答错误或跳过，生成的 JSON 将被 Orchestrator 判定为不合规并要求重生成。

【格式校验（强制）】
生成 stage1_perception_content.json 时，必须严格遵循模板的 _generation_rules：
- logs_distribution = stage1_logs_distribution.json 的**绝对路径字符串**（非 inline JSON）
- metrics_trend = stage1_metrics_trend.json 的**绝对路径字符串**（非 inline JSON）
- trace_flamegraph = stage1_trace_flamegraph.json 的**绝对路径字符串**（非 inline JSON）
- alerts_distribution = stage1_alerts_distribution.json 的**绝对路径字符串**（非 inline JSON）
- topology_map = stage1_topology_map.json 的**绝对路径字符串**（非 inline JSON）
禁止将 5 个数据文件的内容内联到 stage1_perception_content.json 中。

【stage1_topology_map 格式校验】
edges 数组每个元素必须为以下 4 个字段的 JSON 对象：
{ "source": string, "target": string, "label": string, "type": string }
- type 枚举：sync | http | mysql | grpc | async
- 禁止包含 status 字段（status 是节点属性，非边属性）

【stage1_trace_flamegraph 格式校验】
- 顶层字段必须为 trace_root（对象），禁止使用 traces（数组）
- trace_root.color 必须为 hex 颜色值（#开头）
- trace_root.duration_ms 必须为 number 类型（禁止 null）
- trace_root.status 枚举：OK | ERROR | TIMEOUT
- trace_root.children 必须为数组
```

#### Stage 2 — sre-analysis（异常分析）

```
【角色】sre-analysis 智能体，负责检测和识别系统中的异常行为与偏离模式。

【前置输入】Stage 1 产出

【核心职责】
1. 异常检测：基于 metrics_trend 检测指标异常
2. 日志异常分析：识别错误日志模式
3. 链路异常分析：定位异常传播路径
4. 告警异常分析：分析告警状态
5. 拓扑关联分析：构建故障传播链
6. 关联分析：交叉验证 signals，输出 anomaly_patterns_top
7. 输出异常时间线
8. 评估 handoff_ready

【Schema 引用】templates/stage2_analysis_content.json

【输入】incident_id / time_window / environment / stage1 产出 / data_gaps

【输出路径】artifacts/{incident_id}/{incident_id}_stage2_analysis_content.json

【第二步：模板结构确认（强制）】
在生成任何 JSON 内容前，先回答以下问题（不得跳过，不得乱答）：
1. stage2_analysis_content 中 log_anomalies.total_error_logs 是什么类型（number 还是 string）？
2. analysis_overview.handoff_ready 是什么类型（boolean 还是 string）？
3. metric_anomalies[].count 是必须字段吗？
若以上问题回答错误或跳过，生成的 JSON 将被 Orchestrator 判定为不合规并要求重生成。

【历史错误预防（来自 memory）- 强制】
请先执行 memory_search 查询 stage2 相关历史模板错误：
- 查询范围：memory/template_errors/ 目录
- 查询关键词：stage2, {incident_id}
- 无论查询结果是否为空，都必须在 task prompt 中保留本段落；
  - 若查到错误记录，将 prevention_hint 内容追加到【预防提示】；
  - 若查不到任何错误，写入：「未发现相关历史模板错误」
【预防提示】：{Orchestrator 在 spawn 前通过 memory_search 检索 stage2 相关错误，提取 prevention_hint 注入此处。若无历史错误则本段落为"未发现相关历史模板错误"}
```

#### Stage 3 — sre-reasoning（根因推理）

```
【角色】sre-reasoning 智能体，负责深入分析并定位问题的根本原因。

【前置输入】Stage 1 + Stage 2 产出

【核心职责】
1. 假设构建：构建 hypothesis_tree
2. 根因裁决：输出 three_layer_rca
3. 传播拓扑：构建故障传播链
4. 根因时间线：输出事件时间序列
5. 影响分析：输出业务影响
6. 证据关联：交叉验证 signals
7. 输出 overview_conclusion

【Schema 引用】templates/stage3_reasoning_content.json

【输入】incident_id / time_window / environment / stage1+2 产出 / data_gaps

【输出路径】artifacts/{incident_id}/{incident_id}_stage3_reasoning_content.json

【第二步：模板结构确认（强制）】
在生成任何 JSON 内容前，先回答以下问题（不得跳过，不得乱答）：
1. propagation_topology.edges 中是否有 type 字段？（有/无）
2. three_layer_rca[].layer 的可选枚举是什么？（列举）
若以上问题回答错误或跳过，生成的 JSON 将被 Orchestrator 判定为不合规并要求重生成。

【历史错误预防（来自 memory）- 强制】
请先执行 memory_search 查询 stage3 相关历史模板错误：
- 查询范围：memory/template_errors/ 目录
- 查询关键词：stage3, {incident_id}
- 无论查询结果是否为空，都必须在 task prompt 中保留本段落；
  - 若查到错误记录，将 prevention_hint 内容追加到【预防提示】；
  - 若查不到任何错误，写入：「未发现相关历史模板错误」
【预防提示】：禁止包含 solutions 等模板外字段（模板顶层字段：overview_conclusion / hypothesis_tree / root_cause_timeline / propagation_topology / impact_analysis / evidence_data / data_gaps）。{Orchestrator 在 spawn 前通过 memory_search 检索 stage3 相关错误，提取 prevention_hint 注入此处。若无历史错误则本段落为"未发现相关历史模板错误"}

【stage3_reasoning_content 格式校验】
- 顶层禁止出现模板外字段（模板顶层字段：overview_conclusion / hypothesis_tree / root_cause_timeline / propagation_topology / impact_analysis / evidence_data / data_gaps）
- 禁止包含 solutions 字段
- hypothesis_tree.validated_hypotheses[].confidence 类型必须与模板一致
- hypothesis_tree.excluded_hypotheses[].confidence 类型必须与模板一致
```

#### Stage 4 — sre-execution（行动建议）

```
【角色】sre-execution 智能体，负责给出可执行改进方案与人工落地指引。

【前置输入】Stage 1 + Stage 2 + Stage 3 产出

【核心职责】
1. 根因摘要
2. 方案对比：SOL-A/B/C
3. 推荐裁决
4. 执行详情：详细步骤 + 时长
5. 回滚方案
6. 复核清单
7. 残余风险
8. 审批请求

【Schema 引用】templates/stage4_execution_content.json

【输入】incident_id / time_window / environment / stage3 产出 / data_gaps

【输出路径】artifacts/{incident_id}/{incident_id}_stage4_execution_content.json

【第二步：模板结构确认（强制）】
在生成任何 JSON 内容前，先回答以下问题（不得跳过，不得乱答）：
1. detailed_steps 字段的类型是什么？（字符串/字符串数组/对象）
2. rollback_plan 中的字段可以为空字符串吗？（可以/不可以）
若以上问题回答错误或跳过，生成的 JSON 将被 Orchestrator 判定为不合规并要求重生成。

【历史错误预防（来自 memory）- 强制】
请先执行 memory_search 查询 stage4 相关历史模板错误：
- 查询范围：memory/template_errors/ 目录
- 查询关键词：stage4, {incident_id}
- 无论查询结果是否为空，都必须在 task prompt 中保留本段落；
  - 若查到错误记录，将 prevention_hint 内容追加到【预防提示】；
  - 若查不到任何错误，写入：「未发现相关历史模板错误」
【预防提示】：{Orchestrator 在 spawn 前通过 memory_search 检索 stage4 相关错误，提取 prevention_hint 注入此处。若无历史错误则本段落为"未发现相关历史模板错误"}
```

#### Stage 5 — Orchestrator（最终报告）

```
【角色】Orchestrator，综合所有阶段产出生成最终报告。

【前置输入】Stage 1-4 产出

【核心职责】
1. 核心摘要
2. 故障时间线
3. 根因分析
4. 问题与不足
5. 改进计划
6. 结论与风险

【Schema 引用】templates/stage5_final_content.json

【输入】incident_id / time_window / environment / stage1-4 产出 / pipeline_status / analysis_confidence

【输出路径】artifacts/{incident_id}/{incident_id}_stage5_final_content.json

【历史错误预防（来自 memory）】
根据历史模板错误记录，生成时特别注意：
- type 必须为 stage5_final_report（非 stage5_final_content）
- core_summary / fault_timeline / root_cause_and_impact_analysis 等必须为 object（非 string）
- 禁止将嵌套对象展平为字符串字段
{Orchestrator 动态注入：在生成 stage5 前通过 memory_search 检索 stage5 相关错误，提取 prevention_hint 追加到此段落。若无历史错误则此段落为空。}
```

---

## V. 版本变更记录

- **v4.3**（2026-05-11）：所有阶段 task template 新增【第二步：模板结构确认】强制验证节点；【历史错误预防】升级为强制注入（memory_search 必须执行，结果无论是否为空都必须注入）
- **v4.2**（2026-05-11）：所有阶段 task template 新增【历史错误预防】动态注入段落
- **v4.1**（2026-05-11）：Stage 1 新增 topology_map + trace_flamegraph 格式校验；Stage 3 新增 reasoning_content 格式校验（禁止 solutions 等模板外字段）
- **v4.0**（2026-05-08）：重构
