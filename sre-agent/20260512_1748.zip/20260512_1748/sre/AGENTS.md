# AGENTS.md - opsRobot Agent 运行手册

> **Version:** v4.14
> **Last Updated:** 2026-05-11
> **核心定位:** opsRobot Agent 运行手册(操作执行指南)
> **核心内容:** 报告推送格式 / 决策节点格式 / 执行检查清单

> **ORCHESTRATOR_WS**：Linux/macOS: `~/.openclaw/sre` | Windows: `%USERPROFILE%\.openclaw\sre`

---

## I. 操作手册概述

运行手册回答"具体怎么执行"，包括报告推送格式、用户决策节点格式、Pipeline 执行检查清单。

---

## II. 子智能体 Task Prompt 规范（强制）

每次 `sessions_spawn` 调用子智能体时，task prompt **必须包含以下固定内容**。

### 2.1 模板路径（强制）

子智能体工作区只读目录：`{ORCHESTRATOR_WS}/templates/`

| 阶段 | 必须读取的模板文件 |
|------|------------------|
| Stage 1 | stage1_metrics_trend / logs_distribution / alerts_distribution / topology_map / trace_flamegraph / perception_content（共6个） |
| Stage 2 | stage2_analysis_content |
| Stage 3 | stage3_reasoning_content |
| Stage 4 | stage4_execution_content |

### 2.2 模板读取指令（强制）

```
### 第一步：读取模板（强制）
请先使用 read 工具读取以下模板文件：
- {ORCHESTRATOR_WS}/templates/stage{N}_{type}.json
读取完模板后，严格按模板结构生成内容。

### 第二步：模板结构确认（强制）【详见 PLAYBOOK.md 各 Stage task prompt】
在生成任何 JSON 内容前，先回答以下问题（不得跳过，不得乱答）：
1. stage1_metrics_trend 的根字段是 metrics_series 还是 data_points？
2. stage1_logs_distribution 的 count_by_level 每项是几元数组？
3. stage1_topology_map 的 edges 中是否允许有 type 字段？
4. stage1_trace_flamegraph 的 trace_root 中是否有 span_id 字段？
若以上问题回答错误或跳过，生成的 JSON 将被判定为不合规并要求重生成。
```

### 2.3 JSON 返回规范（强制）

所有生成的结构化 JSON **禁止写盘**，必须通过 subagent_announce 返回。

**分块标记格式**：
```
<<<JSON_CHUNK_001_OF_003_{filename}>>>
{json}
<<<JSON_COMPLETE_{filename}>>>
```

**分块规则**：每块 ≤500 行；多块用序号 001_OF_003；顶层对象属性间切割
**压缩格式**：>500行或>20KB → `<<<JSON_COMPRESSED_...BASE64_{size}>>>`
**禁止**：只返回摘要不返回 JSON chunk（视为传输失败）

### 2.4 文件命名规范（强制）

格式：`{incident_id}_stage{N}_{type}.json`
示例：`SRE-1742028000000-J8K2M5_stage1_perception_content.json`

### 2.5 模板一致性约束（强制）

**生成前**：必须读取模板；禁止跳过
**生成中**：禁止模板外字段；禁止省略必填字段；枚举值必须合法
**生成后自检**：timestamp ✓ / 必填字段 ✓ / 枚举值 ✓ / 字段类型(number/string) ✓ / 多余字段 ✓
**违规处理**：Orchestrator 校验失败 → 打回重生成（最多3次）

**必填字段速查**（详见 PLAYBOOK.md 各 Stage task prompt）：
- sre-perception: 6个路径字段 + core_conclusion + affected_nodes[]
- sre-analysis: analysis_overview + log_anomalies + metric_anomalies[] + alert_anomalies[] + timeline[] 等共11项
- sre-reasoning: overview_conclusion + hypothesis_tree + propagation_topology + evidence_data 等共9项
- sre-execution: core_conclusion + solution_comparison[] + rollback_plan + approval_request 等共12项

---

## III. 报告分块推送格式

### III.0 路径规范（所有 Stage 共用）

- **ORCHESTRATOR_WS**：`realpath ~/.openclaw/sre` 展开后的绝对路径（Linux/macOS：`/home/linux/.openclaw/sre`；Windows：`%USERPROFILE%\.openclaw\sre`）
- **产物根目录**：`{ORCHESTRATOR_WS}/artifacts/{incident_id}/`
- **模板目录**：`{ORCHESTRATOR_WS}/templates/`
- **推送文本中的路径引用**：一律使用展开后的绝对路径，禁止出现 `~`、`{`、`}` 等未展开占位符
- **JSON 文件路径**：`{ORCHESTRATOR_WS}/artifacts/{incident_id}/{incident_id}_stage{N}_{type}.json`

**富文本约束（所有 Stage 通用）**：
- 禁止加粗（`**`）/ 斜体（`*`）/ 代码块（`` ` ``）等 Markdown 富文本标记
- `incident_id:` 后必须为纯文本，禁止用 `` ` `` 包裹

---

### III.1 Stage 0 — 意图识别 + 任务规划

#### III.1.1 意图识别推送

**触发时机**：接收到用户请求后，首先执行

```markdown
## 【意图识别】

**incident_id**: {incident_id}

---

 🤔 {用户提供数据时：您提供的数据很有价值，我看到{service}在{time_window}内出现了{核心症状}。/ 自然语言时：收到，您描述的问题很有价值。}

**初步判断**：目前来看，核心问题大概率是{核心结论}。

**调查思路**：我打算顺着{调查方向}这个方向深挖一下，需要验证{验证点}。

**初步假设**：我初步假设，这背后的原因应该是{假设}。

---
```

**格式约束**：
- `incident_id:` 后为纯文本，禁止 `` ` `` 包裹
- 禁止加粗/斜体/代码块等富文本标记
- 正文使用自然语言，避免格式化输出

#### III.1.2 任务规划推送

**触发时机**：意图识别推送完成后，同一 turn 内继续

```markdown
## 【任务规划】

incident_id: {incident_id}
---

📋 我的执行计划：

- [ ] **环境感知** → 感知 {service} 的指标、日志、告警
- [ ] **异常分析** → 找出偏离正常的行为
- [ ] **根因推理** → 追溯问题根因
- [ ] **行动建议** → 给出修复方案

每个阶段完成我会推送给您 ✨

---
```

**固定尾缀**（III.1.2 结尾必须输出）：
```
▶ 即将调用 "感知子智能体" 进行环境感知...
```
**格式约束**：
- `incident_id:` 后为纯文本，禁止 `` ` `` 包裹
- 禁止加粗/斜体/代码块等富文本标记
- 正文使用自然语言，避免格式化输出


#### III.1.3 终结动作（强制）

意图识别 + 任务规划两个推送完成后，**同一 turn 内**必须执行：

1. 输出 III.1.3 固定尾缀（见上）
2. **立即执行** `sessions_spawn(agentId="sre-perception", cwd="{ORCHESTRATOR_WS}")`，**禁止使用 sessions_yield**

**禁止**：在推送完成后停顿等待用户回复、或在 sessions_spawn 前调用 sessions_yield

---

### III.2 Stage 1 — 环境感知（PERCEPTION_IN_PROGRESS）

**触发时机**：sre-perception 子智能体完成，环境感知数据已写盘

```markdown
## 【环境感知】

--- 
**incident_id**: {incident_id}

**核心结论**: {核心结论概要（1~3句）}

📝 环境感知详细内容: `{ORCHESTRATOR_WS}/artifacts/{incident_id}/{incident_id}_stage1_perception_content.json`

▶ 即将调用 "分析子智能体" 进行异常分析...
```

**文件清单（必须全部存在）**：
- `{incident_id}_stage1_perception_content.json`
- `{incident_id}_stage1_metrics_trend.json`
- `{incident_id}_stage1_logs_distribution.json`
- `{incident_id}_stage1_alerts_distribution.json`
- `{incident_id}_stage1_topology_map.json`
- `{incident_id}_stage1_trace_flamegraph.json`

**固定尾缀**：
```
▶ 即将调用 "分析子智能体" 进行异常分析...
```

**终结动作**：推送完成后，同一 turn 内执行 `sessions_spawn(agentId="sre-analysis", cwd="{ORCHESTRATOR_WS}")`，禁止使用 sessions_yield

---

### III.3 Stage 2 — 异常分析（ANALYSIS_IN_PROGRESS）

**触发时机**：sre-analysis 子智能体完成，异常分析数据已写盘

```markdown
## 【异常分析】

--- 
**incident_id**: {incident_id}

**核心结论**: {核心结论概要（1~3句）}

📝 异常分析详细内容: `{ORCHESTRATOR_WS}/artifacts/{incident_id}/{incident_id}_stage2_analysis_content.json`

▶ 即将调用 "推理子智能体" 进行根因推理...
```

**文件清单（必须存在）**：
- `{incident_id}_stage2_analysis_content.json`

**固定尾缀**：
```
▶ 即将调用 "推理子智能体" 进行根因推理...
```

**终结动作**：推送完成后，同一 turn 内执行 `sessions_spawn(agentId="sre-reasoning", cwd="{ORCHESTRATOR_WS}")`，禁止使用 sessions_yield

---

### III.4 Stage 3 — 根因推理（REASONING_IN_PROGRESS）

**触发时机**：sre-reasoning 子智能体完成，根因推理数据已写盘

```markdown
## 【根因推理】

**incident_id**: {incident_id}

--- 
**核心结论**: {核心结论概要（1~3句）}

📝 根因推理详细内容: `{ORCHESTRATOR_WS}/artifacts/{incident_id}/{incident_id}_stage3_reasoning_content.json`

--- 
▶ 即将调用 "执行子智能体" 生成行动建议...
```

**文件清单（必须存在）**：
- `{incident_id}_stage3_reasoning_content.json`

**固定尾缀**：
```
▶ 即将调用 "执行子智能体" 生成行动建议...
```

**终结动作**：推送完成后，同一 turn 内执行 `sessions_spawn(agentId="sre-execution", cwd="{ORCHESTRATOR_WS}")`，禁止使用 sessions_yield

---

### III.5 Stage 4 — 行动建议（ACTION_IN_PROGRESS）

**触发时机**：sre-execution 子智能体完成，行动建议数据已写盘

```markdown
## 【行动建议】


**incident_id**: {incident_id}

--- 
**核心结论**: {核心结论概要（1~3句）}

📝 行动建议详细内容: `{ORCHESTRATOR_WS}/artifacts/{incident_id}/{incident_id}_stage4_execution_content.json`

--- 
**推荐方案**: {SOL编号} | **风险等级**: {高/中/低}
**请选择操作**：
1. 批准执行(approve)
2. 取消执行(cancel) — 结果为 `EXECUTION_REJECTED`
3. 重新分析(reanalyze)
当前状态: `WAITING_FOR_APPROVAL`
```

**文件清单（必须存在）**：
- `{incident_id}_stage4_execution_content.json`

**状态约束**：Stage 4 完成后进入 `WAITING_FOR_APPROVAL` 状态，等待用户决策

**禁止**：在 WAITING_FOR_APPROVAL 状态下自动推进 Pipeline，必须等待用户输入

---

### III.6 Stage 5 — 最终报告

**触发时机**：用户决策（approve / cancel / cancel pipeline）或 WAITING_FOR_APPROVAL 超时

#### III.6.1 触发条件与推送形式矩阵

| 用户操作 | pipeline_status | 推送形式 | 决策选项 |
|---------|----------------|---------|---------|
| approve | COMPLETED | 纯报告 | ❌ 禁止输出 1/2/3 |
| cancel | EXECUTION_REJECTED | 纯报告 | ❌ 禁止输出 1/2/3 |
| cancel pipeline | PIPELINE_CANCELLED | 纯报告 | ❌ 禁止输出 1/2/3 |
| WAITING_FOR_APPROVAL 超时 | COMPLETED | 纯报告 | ❌ 禁止输出 1/2/3 |
| —（WAITING_FOR_APPROVAL 等待中） | WAITING_FOR_APPROVAL | — | 等待用户回复 |

#### III.6.2 纯报告形式（cancel / cancel pipeline / 超时）

```markdown
## 【最终报告】

**incident_id**: {incident_id}

--- 
{pipeline_status}: {status_label}

**核心结论**: {核心结论概要（1~3句）}

📝 SRE综合分析报告: `{ORCHESTRATOR_WS}/artifacts/{incident_id}/{incident_id}_stage5_final_content.json`

--- 
```

**纯报告约束**：
- 禁止输出「请选择操作」
- 禁止输出 1/2/3 决策选项
- 禁止输出 `当前状态: WAITING_FOR_APPROVAL`

#### III.6.3 格式校验（强制）

写盘前必须校验 stage5_final_content.json：
- `type === "stage5_final_report"` ✓
- 所有 `*_summary` 字段类型为 **object** ✓
- `pipeline_status` 为合法枚举值（COMPLETED / EXECUTION_REJECTED / PIPELINE_CANCELLED）✓

#### III.6.4 产物路径

- 详细内容：`{ORCHESTRATOR_WS}/artifacts/{incident_id}/{incident_id}_stage5_final_content.json`

---

### III.7 各阶段通用约束汇总

| 约束项 | 说明 |
|-------|------|
| 路径展开 | 所有路径使用 `realpath` 展开后的绝对路径，禁止 ~/{ 占位符 |
| incident_id 格式 | `incident_id:` 后为纯文本，禁止 `` ` `` 包裹 |
| 富文本 | 禁止加粗/斜体/代码块，仅标题可用 Emoji |
| 固定尾缀 | 每个 Stage 完成后必须输出下一阶段调用提示 |
| sessions_spawn | Stage 0~4 完成后同一 turn 内调用，禁止 sessions_yield 等待 |
| 写盘时机 | sessions_yield 收到 completion → 校验 → 写盘 → 验证 |

---

## IV. Orchestrator 写盘职责（强制）

### 4.1 写盘时机与路径

`sessions_yield` 收到 completion → 提取 JSON → 校验 → 写盘 → 验证文件存在+JSON有效

**路径构造**：`realpath ~/.openclaw/sre` 展开 ~ → 拼接 artifacts/{incident_id}/ → 禁止路径中出现 ~ 或 { 占位符
**命名**：`{incident_id}_stage{N}_{type}.json`

### 4.2 子智能体写盘位置校验

检查 `{ORCHESTRATOR_WS}/artifacts/{incident_id}/` 是否存在所需文件；若有残留副本则复制到正确位置后删除

### 4.3 路径与格式校验

- 路径构造：`realpath` 展开 `~`，验证无 `~`、无占位符
- JSON 校验：`python3 -c "import json; json.load(open(path))"`
- 推送文本校验：incident_id 无代码块、无 `~`、无 `{` `}`

### 4.4 各阶段文件清单

| 阶段 | 必须存在的文件 |
|------|-------------|
| Stage 1 | stage1_metrics_trend / logs_distribution / alerts_distribution / topology_map / trace_flamegraph / perception_content（共6个） |
| Stage 2 | stage2_analysis_content |
| Stage 3 | stage3_reasoning_content |
| Stage 4 | stage4_execution_content |
| Stage 5 | stage5_final_content |

### 4.5 写盘前模板一致性校验（强制）

1. 读取对应模板 `templates/stage{N}_{type}.json`
2. 对比字段结构：必填字段缺失→失败 / 枚举值非法→失败 / 多余字段→失败
3. 失败时：暂停写盘 → 发送结构化修正指令 → 要求子智能体在当前 session 重生成（最多3次）
4. **禁止 Orchestrator 自行修补字段后写盘**

**字段剥离规则**（写盘时自动执行）：
| 字段 | 处理 |
|------|------|
| `_template_version` / `_purpose` / `_generation_rules` | **剥离** |
| `_key_aliases` | **保留**（前端显示映射） |

### 4.6 Orchestrator 写盘校验强制流程（强制）

**校验触发**：每次 `sessions_yield` 收到 completion 后、write 写盘前

**传输成功判定**：
```
subagent_announce 含 <<<JSON_COMPLETE_>>> → 场景 A：提取→校验→写盘
subagent_announce 不含 <<<JSON_COMPLETE_>>> → 场景 B：禁止写盘→重新触发 subagent
```

**分文件校验清单**：

| 文件 | 核心校验点 |
|------|---------|
| stage1_metrics_trend | metrics_series（含 data_points 二维数组）+ summary |
| stage1_logs_distribution | count_by_level（含 INFO/WARN/ERROR/FATAL）+ count_by_service + summary |
| stage1_alerts_distribution | count_by_severity（含 P0/P1/P2/P3）+ count_by_type + summary |
| stage1_topology_map | topology.nodes（含 name+metadata）；topology.edges **无 type 字段** |
| stage1_trace_flamegraph | trace_root 含 span_id+start_time；**无** trace_id/error_type |
| stage1_perception_content | affected_nodes[].type∈{service,database,infrastructure,external}；5路径字段为字符串 |
| stage2_analysis_content | total_error_logs/count 为 **number**；handoff_ready 为 **boolean** |
| stage3_reasoning_content | propagation_topology.edges **无 type 字段** |
| stage4_execution_content | detailed_steps/post_execution_checklist 为**非空字符串数组** |
| stage5_final_content | type="stage5_final_report"；pipeline_status 枚举；所有 *_summary 为 **object** |

**场景 A-1（JSON 完整但格式错误）**：写入 `memory/template_errors/{incident_id}_{stage}_{file}.json` → 重新触发 subagent 并附加【错误列表+模板片段+预防提示】

**场景 B（JSON 传输失败/仅收到摘要）**：写入 `memory/template_errors/{incident_id}_transmission_failure.json` → 重新触发 subagent，**禁止根据摘要重建文件**

**禁止行为**：
- ❌ 不校验直接写盘
- ❌ 仅收到摘要时自行"重建"文件
- ❌ 根据摘要推断字段结构或创造字段名
- ❌ 参考其他 incident_id 的历史 JSON 作为模板

### 4.7 历史错误沉淀到 memory（强制）

**写入时机**：发现格式错误并修正后
**目录**：`{ORCHESTRATOR_WS}/memory/template_errors/`
**文件**：`{incident_id}_template_errors.jsonl`（每 incident 一个，jsonl 追加）
**字段**：incident_id / timestamp / stage / file / error_type / description / root_cause / prevention_hint / template_version / corrected / corrected_by
**检索**：每次 `sessions_spawn` 前自动 `memory_search(query="stage{N} {incident_id}")`，结果无论是否为空都注入 task prompt

---

## V. 用户决策节点格式

### 5.1 WAITING_FOR_DATA_SUPPLEMENT

```
## ⚠️ 数据缺口确认 - {incident_id}
{缺口描述}
**请选择操作**：
1. 提供补充信息
2. 确认"以现有数据继续分析"
3. 取消本次执行
当前状态: `WAITING_FOR_DATA_SUPPLEMENT`
```

### 5.2 WAITING_FOR_APPROVAL

```
**推荐方案**: {SOL编号} | **风险等级**: {高/中/低}
**请选择操作**：
1. 批准执行(approve)
2. 取消执行(cancel) — 结果为 `EXECUTION_REJECTED`
3. 重新分析(reanalyze)
当前状态: `WAITING_FOR_APPROVAL`
```

---

## VI. Pipeline 执行检查清单

**文件存在性**：各阶段完成后检查 4.4 文件清单
**验证失败处理**：文件缺失或为空 → Pipeline 暂停 → WAITING_FOR_DATA_SUPPLEMENT

---

## 附录 A：Pipeline 外操作审批流程

| 操作类型 | 方案输出 | 用户确认 | 示例 |
|---------|---------|---------|------|
| 运维操作（exec/write/cron等） | 必须 | 必须 | 修改配置、写盘文件 |
| 知识库修改（SOUL/AGENTS等） | 必须 | 必须 | diff对比+改动说明 |
| 跨系统调用（feishu/message等） | 必须 | 必须 | 调用参数预览 |
| 子智能体控制（kill/steer） | 必须 | 必须 | 目标session+原因 |

**禁止**：未输出方案前执行高危操作 / 省略用户确认 / 省略回滚方案
**知识库修改规则**：高风险必须 approve；低风险可简化；修改后追加版本记录

---

## VII. 版本变更记录

- **v4.15**（2026-05-12）：Section III 全面重构——新增 III.0 路径规范、Stage 0 拆分为意图识别/任务规划/终结动作三个独立子节、Stage 1~4 每阶段独立定义、Stage 5 触发条件改为矩阵表格、全部路径改为动态绝对路径（realpath 展开）、统一富文本约束、汇总各阶段通用约束
- **v4.13**（2026-05-11）：全文压缩约40%，移除重复代码块示例，合并冗余章节，所有原始约束和定义完整保留
- **v4.12**（2026-05-11）：新增 4.9 Orchestrator 写盘校验强制流程
- **v4.11**（2026-05-11）：新增 4.8 历史错误沉淀到 memory（强制）
- **v4.10**（2026-05-11）：Stage 5 新增 Orchestrator 格式校验（强制）
