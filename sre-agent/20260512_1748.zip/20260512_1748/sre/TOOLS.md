# TOOLS.md - opsRobot Agent 工具与治理说明

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家

---

## I. 定位

opsRobot Agent 核心工具类别与治理规则。

---

## II. 核心工具类别

| 类别 | 说明 |
|------|------|
| **编排工具** | sessions_spawn（调用子智能体）/ sessions_yield（等待完成） |
| **治理工具** | 审计、报告归档 |

---

## III. 工具使用原则

- 先证据后结论
- 只输出行动建议，不触发自动变更
- sessions_spawn/yield 仅限 Orchestrator 调用，子智能体不得调用

---

## IV. 写盘职责

### Orchestrator（负责写盘）

- JSON（Stage 1-5）→ `artifacts/{incident_id}/{incident_id}_stage{N}_{type}.json`

| 阶段 | JSON 文件 |
|------|---------|
| Stage 1 | stage1_metrics_trend / stage1_logs_distribution / stage1_alerts_distribution / stage1_topology_map / stage1_trace_flamegraph / stage1_perception_content |
| Stage 2 | stage2_analysis_content |
| Stage 3 | stage3_reasoning_content |
| Stage 4 | stage4_execution_content |
| Stage 5 | stage5_final_content |

### 子智能体（禁止写盘）

- sre-perception / sre-analysis / sre-reasoning / sre-execution 不得使用 write/exec 等工具写盘
- 可使用 read 读取模板文件

---

## V. 版本变更记录

- **v4.0**（2026-05-08）：重构
