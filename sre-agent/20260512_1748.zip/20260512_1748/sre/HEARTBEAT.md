# HEARTBEAT.md - opsRobot Agent 心跳治理清单

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家

---

## I. 定位

opsRobot Agent Pipeline 心跳监控与巡检规范。

---

## II. 心跳机制

### 巡检频率

- 轻量巡检（每 30 分钟）：IDLE / WAITING_FOR_APPROVAL 时健康检查
- 故障高峰巡检（每 10 分钟）：*_IN_PROGRESS / TIMED_OUT 时加速监控
- 事件驱动（按需）：用户发起 / 子智能体完成 / 超时通知
- 周期性任务（自定义）：Cron 驱动后台任务

---

## III. 超时阈值

上限 900 秒（L4 乘数 × 基础超时，封顶值）

| 子智能体 | 基础超时 |
|---------|---------|
| sre-perception | 240s |
| sre-analysis | 300s |
| sre-reasoning | 300s |
| sre-execution | 240s |

---

## IV. 超时处理

```
超时 → 检查 sessions_yield 是否已返回数据
  ├── 已返回（任意阶段）→ Orchestrator 提取写盘，继续 Pipeline，报告注明"超时前已返回数据，已由 Orchestrator 写盘"
  └── 完全未返回 → 暂停 Pipeline，输出 WAITING_FOR_DATA_SUPPLEMENT
```

---

## V. 心跳检查清单

### Stage 0

- service / symptom / time_window / environment 字段齐全
- incident_id 格式 SRE-{ts_ms}-{rand6}
- 意图识别 + 任务规划输出已推送

### Stage 1 — PERCEPTION_IN_PROGRESS

- stage1_perception_content / stage1_metrics_trend / stage1_logs_distribution / stage1_alerts_distribution / stage1_topology_map / stage1_trace_flamegraph

### Stage 2 — ANALYSIS_IN_PROGRESS

- stage2_analysis_content

### Stage 3 — REASONING_IN_PROGRESS

- stage3_reasoning_content

### Stage 4 — EXECUTION_IN_PROGRESS

- stage4_execution_content
- WAITING_FOR_APPROVAL（1/2/3 选项）已输出

### Stage 5 — 最终报告

- stage5_final_content

---

## VI. 系统健康度巡检

### Workspace 健康检查

- `artifacts/` 目录存在且可写
- `BOOTSTRAP.md` 存在
- incident_id 占位符校验（写盘前必须验证路径中不包含 XXXXXX）

### Pipeline 健康检查

- Stage 0 先于任何 sessions_spawn
- Stage 1→2→3→4 串行执行
- 落盘文件命名：`{incident_id}_stage{N}_{type}.json`
- incident_id 唯一性（拒绝复用）

---

## VII. 告警阈值

触发即时通知：

- Pipeline 卡死：同一 Stage 超过 10 分钟无状态变化
- 连续超时：连续 2 个 Stage 超时
- 落盘失败：证据支撑 JSON 写入失败
- 用户操作超时：WAITING_FOR_APPROVAL 超过 10 分钟

---

## VIII. 运营指标

- Stage 执行成功率 > 90%
- 超时率 < 10%
- 数据充分率 > 80%
- Pipeline 完成率 > 95%

---

## IX. 版本变更记录

- **v4.0**（2026-05-08）：重构
