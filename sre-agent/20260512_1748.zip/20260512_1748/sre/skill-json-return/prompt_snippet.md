# JSON 返回协议 - Task Prompt 片段

> **Version:** v1.0
> **Last Updated:** 2026-05-09
> **用途:** 粘贴到所有子智能体 task prompt 的【核心职责】章节之后

---

## JSON 返回规范（强制）

所有生成的结构化 JSON **禁止写盘**，必须通过 subagent_announce 返回给 Orchestrator。

### 第一步：判断文件大小

生成完所有 JSON 后，检查每个文件的行数和字节数：
- 若所有文件 ≤500 行 且 ≤20KB → 使用 **A-1 分块 JSON**
- 若任何文件 >500 行 或 >20KB → 该文件使用 **B 压缩 JSON**，其他文件使用 A-1

### 第二步：选择格式

**A-1 分块 JSON（默认）**：
```
<<<JSON_CHUNK_001_OF_003_{filename}>>>
{json_content_part_1}
<<<JSON_CHUNK_END>>>

<<<JSON_CHUNK_002_OF_003_{filename}>>>
{json_content_part_2}
<<<JSON_CHUNK_END>>>

<<<JSON_CHUNK_003_OF_003_{filename}>>>
{json_content_part_3}
<<<JSON_CHUNK_END>>>

<<<JSON_COMPLETE_{filename}>>>
```

**B 压缩 JSON（>500行 或 >20KB 时自动启用）**：
```
<<<JSON_COMPRESSED_{filename}_BASE64_{original_size}>>>
{base64_encoded_zlib_compressed_data}
<<<JSON_COMPRESSED_END>>>
```

### 第三步：分块规则
- 每个 Chunk 不超过 **500 行 JSON**
- Chunk 序号格式：`001_OF_003`（3位数字，不够补0）
- 分块位置：在 JSON 顶层对象的属性之间切割，避免在嵌套对象中间截断

### 第四步：完整性标记
- 每个文件最后一个 Chunk 后必须包含 `<<<JSON_COMPLETE_{filename}>>>`
- Orchestrator 通过此标记确认文件传输完成

### 第五步：subagent_announce 返回格式

**多文件返回示例**：
```
<<<JSON_CHUNK_001_OF_001_SRE-1746777840000-Q7M2P4_stage1_metrics_trend.json>>>
{...完整 JSON...}
<<<JSON_CHUNK_END>>>
<<<JSON_COMPLETE_SRE-1746777840000-Q7M2P4_stage1_metrics_trend.json>>>

<<<JSON_CHUNK_001_OF_001_SRE-1746777840000-Q7M2P4_stage1_logs_distribution.json>>>
{...完整 JSON...}
<<<JSON_CHUNK_END>>>
<<<JSON_COMPLETE_SRE-1746777840000-Q7M2P4_stage1_logs_distribution.json>>>

<<<JSON_CHUNK_001_OF_002_SRE-1746777840000-Q7M2P4_stage1_perception_content.json>>>
{...第1部分...}
<<<JSON_CHUNK_END>>>

<<<JSON_CHUNK_002_OF_002_SRE-1746777840000-Q7M2P4_stage1_perception_content.json>>>
{...第2部分...}
<<<JSON_CHUNK_END>>>
<<<JSON_COMPLETE_SRE-1746777840000-Q7M2P4_stage1_perception_content.json>>>
```

### 禁止事项
- ❌ 禁止只返回人类可读摘要
- ❌ 禁止在 subagent_announce 中写盘
- ❌ 禁止省略 `<<<JSON_COMPLETE_*>>>` 标记
