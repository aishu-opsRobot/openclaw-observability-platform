# SKILL.md - JSON 返回协议

> **Version:** v1.0
> **Last Updated:** 2026-05-09
> **核心定位:** 子智能体 JSON 返回规范与 Orchestrator 解析协议
> **适用范围:** sre-perception / sre-analysis / sre-reasoning / sre-execution

---

## I. 背景

subagent_announce 返回的内容容易被截断，且纯文本摘要无法被 Orchestrator 解析为结构化 JSON。本协议提供分块 + 压缩双重保障，确保大型 JSON 可以完整传输。

---

## II. 核心设计

**双重保障机制**：
- **默认**：A-1 分块 JSON（Chunked JSON）
- **自动升级**：当单个文件超过阈值（500 行或 20KB）时，自动切换为 B 压缩（Base64）

**流程**：
```
子智能体生成 JSON
    ↓
文件大小检测
    ↓
├── ≤500行 且 ≤20KB → A-1 分块 JSON
└── >500行 或 >20KB → B Base64 压缩
    ↓
subagent_announce 返回
    ↓
Orchestrator 解析 + 验证 + 写盘
```

---

## III. 格式规范

### A-1 分块 JSON（默认）

**触发条件**：单个文件 ≤500 行 且 ≤20KB

**格式**：
```
<<<JSON_CHUNK_001_OF_003_{filename}>>>
{json_content_part_1}
<<<JSON_CHUNK_END>>>

<<<JSON_CHUNK_002_OF_003_{filename}>>>
{json_content_part_2}
<<<JSON_CHUNK_END>>>

<<<JSON_CHUNK_003_OF_003_{filename}>>>
{json_content_part_3}
<<<JSON_CHUNK_END>>>

<<<JSON_COMPLETE_{filename}>>>
```

**分块规则**：
- 每个 Chunk 不超过 **500 行 JSON**
- Chunk 序号格式：`001_OF_003`（3位数字，不够补0）
- 分块位置：在 JSON 顶层对象的属性之间切割，避免在嵌套对象中间截断

---

### B 压缩 JSON（兜底）

**触发条件**：单个文件 >500 行 或 >20KB

**格式**：
```
<<<JSON_COMPRESSED_{filename}_BASE64_{original_size}>>>
{base64_encoded_zlib_compressed_data}
<<<JSON_COMPRESSED_END>>>
```

**编码要求**：
- 先用 `zlib.compress()` 压缩
- 再用 `base64.b64encode()` 编码
- original_size：原始 JSON 字节数（用于校验）

---

## IV. 子智能体 Task Prompt 规范

在所有子智能体的 task prompt 中，**必须**包含以下章节：

---

### JSON 返回规范（强制）

所有生成的结构化 JSON **禁止写盘**，必须通过 subagent_announce 返回给 Orchestrator。

**第一步：判断文件大小**

生成完所有 JSON 后，检查每个文件的行数和字节数：
- 若所有文件 ≤500 行 且 ≤20KB → 使用 **A-1 分块 JSON**
- 若任何文件 >500 行 或 >20KB → 该文件使用 **B 压缩 JSON**，其他文件使用 A-1

**第二步：选择格式**

**A-1 分块 JSON（默认）**：
```
<<<JSON_CHUNK_001_OF_003_{filename}>>>
{json_content_part_1}
<<<JSON_CHUNK_END>>>

<<<JSON_CHUNK_002_OF_003_{filename}>>>
{json_content_part_2}
<<<JSON_CHUNK_END>>>

<<<JSON_COMPLETE_{filename}>>>
```

**B 压缩 JSON（>500行 或 >20KB 时自动启用）**：
```
<<<JSON_COMPRESSED_{filename}_BASE64_{original_size}>>>
{base64_encoded_zlib_compressed_data}
<<<JSON_COMPRESSED_END>>>
```

**第三步：分块规则**
- 每个 Chunk 不超过 **500 行 JSON**
- Chunk 序号格式：`001_OF_003`（3位数字，不够补0）
- 分块位置：在 JSON 顶层对象的属性之间切割，避免在嵌套对象中间截断

**第四步：完整性标记**
- 每个文件最后一个 Chunk 后必须包含 `<<<JSON_COMPLETE_{filename}>>>`
- Orchestrator 通过此标记确认文件传输完成

**示例：A-1 多文件返回**
```
<<<JSON_CHUNK_001_OF_001_SRE-xxx_stage1_metrics_trend.json>>>
{...}
<<<JSON_CHUNK_END>>>
<<<JSON_COMPLETE_SRE-xxx_stage1_metrics_trend.json>>>

<<<JSON_CHUNK_001_OF_001_SRE-xxx_stage1_logs_distribution.json>>>
{...}
<<<JSON_CHUNK_END>>>
<<<JSON_COMPLETE_SRE-xxx_stage1_logs_distribution.json>>>

<<<JSON_COMPRESSED_SRE-xxx_stage1_perception_content.json_BASE64_31280>>>
{base64...}
<<<JSON_COMPRESSED_END>>>
```

---

## V. Orchestrator 解析逻辑

### parse_subagent_announce(message_content: str) -> dict[str, str | None]

```python
import re
import base64
import zlib
import json

def parse_subagent_announce(message_content: str) -> dict[str, str | None]:
    """
    解析 subagent_announce 返回的内容。
    返回: {filename: json_string}，不完整的文件返回 None
    """
    result = {}

    # ==================== B 压缩格式解析 ====================
    compressed_pattern = r'<<<JSON_COMPRESSED_(\S+)_BASE64_(\d+)>>>\s*(.+?)\s*<<<JSON_COMPRESSED_END>>>'
    for match in re.finditer(compressed_pattern, message_content, re.DOTALL):
        filename = match.group(1)
        original_size = int(match.group(2))
        encoded_data = match.group(3).strip()
        
        try:
            compressed = base64.b64decode(encoded_data)
            decompressed = zlib.decompress(compressed)
            json_str = decompressed.decode('utf-8')
            
            # 验证大小
            if len(json_str.encode('utf-8')) != original_size:
                print(f"⚠️ {filename} 大小校验失败: 期望 {original_size}, 实际 {len(json_str.encode('utf-8'))}")
            
            result[filename] = json_str
        except Exception as e:
            print(f"❌ {filename} 解压失败: {e}")
            result[filename] = None

    # ==================== A-1 分块格式解析 ====================
    chunk_pattern = r'<<<JSON_CHUNK_(\d+)_OF_(\d+)_(\S+?)>>>\s*(.+?)\s*<<<JSON_CHUNK_END>>>'
    
    # 按文件名分组收集 chunks
    file_chunks = {}
    for match in re.finditer(chunk_pattern, message_content, re.DOTALL):
        seq = int(match.group(1))
        total = int(match.group(2))
        filename = match.group(3)
        content = match.group(4).strip()
        
        if filename not in file_chunks:
            file_chunks[filename] = {'total': total, 'chunks': {}}
        file_chunks[filename]['chunks'][seq] = content

    # 拼接并验证
    for filename, data in file_chunks.items():
        # 检查是否已通过压缩方式处理
        if filename in result and result[filename] is not None:
            continue
            
        chunks = data['chunks']
        if len(chunks) != data['total']:
            print(f"⚠️ {filename} Chunk 不完整: 收到 {len(chunks)}/{data['total']}")
            result[filename] = None
            continue
        
        # 按序号拼接
        sorted_chunks = [chunks[i] for i in sorted(chunks.keys())]
        full_json = ''.join(sorted_chunks)
        
        # 验证 JSON 格式
        try:
            json.loads(full_json)
            result[filename] = full_json
        except json.JSONDecodeError as e:
            print(f"❌ {filename} JSON 解析失败: {e}")
            result[filename] = None

    # ==================== 完整性校验 ====================
    complete_pattern = r'<<<JSON_COMPLETE_(\S+?)>>>'
    completed_files = set(re.findall(complete_pattern, message_content))
    
    for filename in completed_files:
        if filename not in result or result[filename] is None:
            print(f"⚠️ {filename} 标记为 COMPLETE 但解析失败")

    return result
```

---

## VI. 错误处理

| 错误场景 | 处理方式 |
|---------|---------|
| Chunk 不完整（缺少数） | 跳过该文件，打印警告，Orchestrator 继续处理其他文件 |
| Chunk 序号重复 | 取第一个，忽略后续 |
| Base64 解码失败 | 跳过该文件，打印错误 |
| zlib 解压失败 | 跳过该文件，打印错误 |
| JSON 验证失败 | 跳过该文件，打印错误 |
| 大小校验失败 | 打印警告但不跳过（可能有编码差异） |

---

## VII. 版本变更记录

- **v1.0**（2026-05-09）：初始版本，A-1 分块 JSON + B 压缩 JSON 双重保障
