#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JSON 返回协议解析工具
Version: v1.0
Last Updated: 2026-05-09

Usage:
    from parser import parse_subagent_announce, write_artifacts
"""

import re
import base64
import zlib
import json
import os
from typing import Optional


def parse_subagent_announce(message_content: str) -> dict[str, Optional[str]]:
    """
    解析 subagent_announce 返回的内容。
    
    Args:
        message_content: subagent_announce 返回的原始文本内容
        
    Returns:
        dict[str, Optional[str]]: {filename: json_string}，不完整的文件返回 None
    """
    result = {}

    # ==================== B 压缩格式解析 ====================
    # 格式: <<<JSON_COMPRESSED_{filename}_BASE64_{original_size}>>>...<<<JSON_COMPRESSED_END>>>
    compressed_pattern = r'<<<JSON_COMPRESSED_(\S+?)_BASE64_(\d+)>>>\s*(.+?)\s*<<<JSON_COMPRESSED_END>>>'
    for match in re.finditer(compressed_pattern, message_content, re.DOTALL):
        filename = match.group(1)
        original_size = int(match.group(2))
        encoded_data = match.group(3).strip()
        
        try:
            # Base64 解码
            compressed = base64.b64decode(encoded_data)
            # zlib 解压
            decompressed = zlib.decompress(compressed)
            json_str = decompressed.decode('utf-8')
            
            # 验证大小
            actual_size = len(json_str.encode('utf-8'))
            if actual_size != original_size:
                print(f"⚠️ {filename} 大小校验失败: 期望 {original_size}, 实际 {actual_size}")
            
            result[filename] = json_str
            print(f"✅ {filename} 解压成功 ({actual_size} bytes)")
        except Exception as e:
            print(f"❌ {filename} 解压失败: {e}")
            result[filename] = None

    # ==================== A-1 分块格式解析 ====================
    # 格式: <<<JSON_CHUNK_{seq}_OF_{total}_{filename}>>>...<<<JSON_CHUNK_END>>>
    chunk_pattern = r'<<<JSON_CHUNK_(\d+)_OF_(\d+)_(\S+?)>>>\s*(.+?)\s*<<<JSON_CHUNK_END>>>'
    
    # 按文件名分组收集 chunks
    file_chunks = {}
    for match in re.finditer(chunk_pattern, message_content, re.DOTALL):
        seq = int(match.group(1))
        total = int(match.group(2))
        filename = match.group(3)
        content = match.group(4).strip()
        
        if filename not in file_chunks:
            file_chunks[filename] = {'total': total, 'chunks': {}}
        
        # 序号重复时取第一个
        if seq not in file_chunks[filename]['chunks']:
            file_chunks[filename]['chunks'][seq] = content

    # 拼接并验证
    for filename, data in file_chunks.items():
        # 检查是否已通过压缩方式处理
        if filename in result and result[filename] is not None:
            continue
            
        chunks = data['chunks']
        total = data['total']
        
        if len(chunks) != total:
            print(f"⚠️ {filename} Chunk 不完整: 收到 {len(chunks)}/{total}")
            result[filename] = None
            continue
        
        # 按序号拼接
        sorted_chunks = [chunks[i] for i in sorted(chunks.keys())]
        full_json = ''.join(sorted_chunks)
        
        # 验证 JSON 格式
        try:
            json.loads(full_json)
            result[filename] = full_json
            print(f"✅ {filename} 拼接成功 ({len(full_json)} bytes, {len(chunks)} chunks)")
        except json.JSONDecodeError as e:
            print(f"❌ {filename} JSON 解析失败: {e}")
            result[filename] = None

    # ==================== 完整性校验 ====================
    complete_pattern = r'<<<JSON_COMPLETE_(\S+?)>>>'
    completed_files = set(re.findall(complete_pattern, message_content))
    
    for filename in completed_files:
        if filename not in result or result[filename] is None:
            print(f"⚠️ {filename} 标记为 COMPLETE 但解析失败")

    return result


def write_artifacts(incident_id: str, parsed: dict[str, Optional[str]], workspace: str) -> dict[str, bool]:
    """
    将解析后的 JSON 写入磁盘。
    
    Args:
        incident_id: 事件 ID
        parsed: parse_subagent_announce 返回的解析结果
        workspace: 工作区根目录
        
    Returns:
        dict[str, bool]: {filename: success}
    """
    import os
    
    artifact_dir = os.path.join(workspace, 'artifacts', incident_id)
    os.makedirs(artifact_dir, exist_ok=True)
    
    results = {}
    for filename, json_str in parsed.items():
        if json_str is None:
            print(f"⏭️ 跳过 {filename}（解析失败）")
            results[filename] = False
            continue
        
        filepath = os.path.join(artifact_dir, filename)
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(json_str)
            
            # 验证写入
            with open(filepath, 'r', encoding='utf-8') as f:
                json.load(f)
            
            print(f"✅ 已写入: {filename}")
            results[filename] = True
        except Exception as e:
            print(f"❌ 写入失败 {filename}: {e}")
            results[filename] = False
    
    return results


def compress_json(json_str: str) -> tuple[bytes, int]:
    """
    将 JSON 字符串压缩为 Base64 编码。
    
    Args:
        json_str: JSON 字符串
        
    Returns:
        (base64_encoded_string, original_size)
    """
    original_size = len(json_str.encode('utf-8'))
    compressed = zlib.compress(json_str.encode('utf-8'))
    encoded = base64.b64encode(compressed).decode('ascii')
    return encoded, original_size


def chunk_json(json_str: str, max_lines: int = 500) -> list[tuple[int, int, str]]:
    """
    将 JSON 字符串分块。
    
    Args:
        json_str: JSON 字符串
        max_lines: 每个块的最大行数
        
    Returns:
        [(seq, total, chunk_content), ...]
    """
    lines = json_str.split('\n')
    total_chunks = (len(lines) + max_lines - 1) // max_lines
    
    chunks = []
    for i in range(total_chunks):
        start = i * max_lines
        end = min((i + 1) * max_lines
        chunk_content = '\n'.join(lines[start:end])
        chunks.append((i + 1, total_chunks, chunk_content))
    
    return chunks


# ==================== 测试代码 ====================
if __name__ == '__main__':
    # 测试分块
    test_json = json.dumps({
        "incident_id": "SRE-1234567890000-TEST01",
        "test_data": ["item"] * 1000
    }, indent=2)
    
    print(f"原始 JSON: {len(test_json)} bytes, {len(test_json.split(chr(10)))} lines")
    
    chunks = chunk_json(test_json, max_lines=10)
    print(f"分块数量: {len(chunks)}")
    
    # 测试压缩
    encoded, size = compress_json(test_json)
    print(f"压缩后: {len(encoded)} bytes (原始: {size})")
    
    # 测试解析
    test_message = f"""<<<JSON_CHUNK_001_OF_002_test.json>>>
{{"part": 1}
<<<JSON_CHUNK_END>>>

<<<JSON_CHUNK_002_OF_002_test.json>>>
,"part": 2}}
<<<JSON_CHUNK_END>>>

<<<JSON_COMPLETE_test.json>>>

<<<JSON_COMPRESSED_large.json_BASE64_{size}>>>
{encoded}
<<<JSON_COMPRESSED_END>>>"""
    
    print("\n--- 解析测试 ---")
    result = parse_subagent_announce(test_message)
    for fname, content in result.items():
        print(f"{fname}: {'成功' if content else '失败'}")
