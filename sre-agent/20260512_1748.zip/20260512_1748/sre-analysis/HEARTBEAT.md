# HEARTBEAT.md - opsRobot Agent 分析智能体心跳治理清单

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

---

## I. 定位

opsRobot Agent 分析智能体心跳治理清单，定义健康检查、阶段报告格式验证。

---

## II. 心跳机制

- 轻量巡检（每 30 分钟）：IDLE 时健康检查
- 故障高峰巡检（每 10 分钟）：ANALYSIS_IN_PROGRESS 时加速监控
- 事件驱动（按需）：Orchestrator 调用 / 分析完成 / 超时通知

---

## III. 超时阈值（快速索引）

| 子智能体 | 基础超时 | L1（×1.0）| L2（×1.5）| L3（×2.0）| L4（×3.0）| 上限 |
|---------|---------|---------|---------|---------|---------|------|
| sre-analysis | 300s | 300s | 450s | 600s | 900s | 900s |

---

## IV. Stage 2 健康检查清单

### 4.1 执行前检查

- [ ] 读取 SOUL.md（最高优先级）
- [ ] 读取 IDENTITY.md
- [ ] 读取 USER.md
- [ ] 读取 memory/YYYY-MM-DD.md（今天、昨天，存在则读取）
- [ ] 确认 incident_id 格式正确
- [ ] 确认 stage1_perception_content 完整度

### 4.2 异常分析检查

- [ ] 异常检测完成（基线对比 + 统计异常检测 + 阈值告警）
- [ ] 安全规则检测完成（Sigma 规则匹配）
- [ ] 异常识别完成（分类 + 偏离量化 + 定位）
- [ ] 跨支柱关联分析完成（alerts × metrics × logs × traces）
- [ ] 信号分层完成（strong / weak / unknown）
- [ ] 异常模式识别完成（Top N）

### 4.3 交付物检查

- [ ] stage2_analysis_content 结构完整
- [ ] handoff_ready 标记正确（true / false）
- [ ] status 标记正确（success / partial）
- [ ] 阶段报告格式符合规范（6 子节，顺序固定）

### 4.4 数据质量检查

- [ ] 异常分类正确
- [ ] 偏离量化有证据支撑
- [ ] 相关性表述未混淆为因果
- [ ] degraded_paths 透明记录
- [ ] 安全检测结果置信度标注正确

---

## V. 版本变更记录

- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义
- **v0.5.0**（2026-04-23）：分析智能体心跳治理清单
