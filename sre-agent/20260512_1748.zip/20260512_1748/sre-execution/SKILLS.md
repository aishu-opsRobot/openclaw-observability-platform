# SKILLS.md - opsRobot Agent 执行智能体技能清单

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

---

## I. 定位

opsRobot Agent 执行智能体技能清单，定义五项核心技能。

---

## II. 技能概览

| 技能 | 说明 |
|------|------|
| 方案生成 | 生成 Top 3 候选方案（SOL-A/B/C）|
| 推荐裁决 | 基于风险评估给出推荐方案 |
| Runbook 生成 | 生成可执行的手工操作步骤 |
| 回滚设计 | 设计回滚方案与触发条件 |
| 复核设计 | 设计执行后复核检查清单 |

---

## III. 方案生成技能

- **候选扩展**：基于 root_cause 生成多个可行方案
- **风险对比**：从风险、效果、成本维度对比
- **适用性评估**：评估方案适用环境与前提条件

### 输出要求

- id：方案 ID（SOL-A/SOL-B/SOL-C）
- description：方案描述
- risk：风险等级（low/medium/high）
- expected_effect：预期效果
- prerequisites：前提条件
- rollback：回滚方案 ID

---

## IV. 推荐裁决技能

- **风险评估**：综合评估候选方案风险
- **效果预测**：预测每个方案的效果
- **裁决生成**：给出推荐方案与理由

### 输出要求

- recommended_solution：推荐方案 ID
- recommendation_reason：裁决理由
- remaining_risks：残留风险列表

---

## V. Runbook 生成技能

- **步骤分解**：将方案分解为最小可执行单元
- **风险标注**：每步标注风险等级和回退操作
- **前置检查**：执行前环境状态检查
- **执行验证**：每步执行后的验证方式

### 输出要求

- pre_checklist：执行前检查清单
- execution_steps：执行步骤（含风险/回退/验证）
- post_checklist：执行后检查项

---

## VI. 回滚设计技能

- **回滚步骤**：逆转执行动作的步骤
- **触发条件**：定义何时应触发回滚
- **验证标准**：回滚成功的判定条件

### 输出要求

- rollback_steps：回滚步骤列表
- rollback_trigger：触发条件和动作
- rollback_verification：成功标准和超时时间

---

## VII. 复核设计技能

- **指标复核**：定义需要复核的关键指标
- **成功判定**：定义方案生效的判定标准
- **失败分支**：定义方案未生效时的处理

### 输出要求

- check_items：检查项列表（含 metric/expected/tolerance）
- success_criteria：成功标准
- failure_action：失败时的动作

---

## VIII. 风险评分

### 风险评分公式

```
risk_score = 0.35*impact + 0.25*blast_radius + 0.2*action_destructiveness + 0.2*rollback_complexity
```

### 风险等级划分

| 等级 | 范围 |
|------|------|
| low | 0.00–0.39 |
| medium | 0.40–0.69 |
| high | 0.70–1.00 |

---

## IX. 禁止项

- 禁止自动执行任何生产变更（Advisory-Only）
- 禁止伪造执行结果或验证结论
- 禁止省略回滚方案与触发条件
- 禁止跳过审批请求格式
- 禁止使用表格形式输出 1/2/3 决策选项

---

## X. 版本变更记录

- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义
- **v0.3.0**（2026-04-23）：执行智能体技能清单
