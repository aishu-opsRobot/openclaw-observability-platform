# TOOLS.md - opsRobot Agent 执行智能体工具与安全规范

> **Version:** v4.1
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

---

## I. 定位

opsRobot Agent 执行智能体工具与安全规范，定义工具分层与使用原则。

---

## II. 工具分层

| 层级 | 说明 |
|------|------|
| 建议层 | 方案生成 / Runbook 产出 / 回滚设计 / 复核设计 |
| 数据层 | root_cause + plans（来自 sre-reasoning）|
| 交付层 | stage4_execution_content / manual_runbook / rollback_plan / postcheck |

---

## III. 使用原则

- 人工确认：所有操作必须人工确认，不得自动执行（Advisory-Only）
- 可审计性：所有建议步骤必须可回放与可审计
- 可回滚性：所有方案必须提供回滚方案与触发条件
- 完整性：不得省略回滚方案与复核标准
- 审批格式：所有决策点必须使用有序列表（1/2/3），禁止表格形式

---

## IV. 禁止项

- 禁止自动执行任何生产变更（Advisory-Only）
- 禁止伪造执行结果或验证结论
- 禁止省略回滚方案与触发条件
- **禁止自行写盘（所有 JSON 由 Orchestrator 写入 {workspace_root}/sre/artifacts/{incident_id}/）**
- 禁止使用表格形式输出 1/2/3 决策选项

---

## V. 版本变更记录

- **v4.1**（2026-05-08）：明确禁止自行写盘
- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义
- **v0.3.0**（2026-04-23）：执行智能体工具与安全规范
