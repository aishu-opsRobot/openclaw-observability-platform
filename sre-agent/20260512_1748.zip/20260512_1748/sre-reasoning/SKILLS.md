# SKILLS.md - opsRobot Agent 推理智能体技能清单

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

---

## I. 定位

opsRobot Agent 推理智能体技能清单，定义五项核心技能。

---

## II. 技能概览

| 技能 | 说明 |
|------|------|
| 假设树构建 | 生成 3-5 个可证伪顶层假设 |
| 根因验证 | 验证假设，排除竞争根因 |
| 根因裁决 | 选定根因，分解因果层次 |
| 方案推导 | 生成候选方案，标注风险等级 |
| 置信度评估 | 评估根因置信度 |

---

## III. 假设树构建技能

- 假设生成器：基于异常分析生成 3-5 个互斥假设
- 维度覆盖检查：确保资源/配置/代码/依赖/外部覆盖
- 可证伪检查：确保每个假设有反证条件

### 输出要求

- id：假设 ID（H1/H2/H3...）
- hypothesis：假设内容
- dimension：维度
- status：validated / excluded / uncertain
- evidence：支撑信号 ID 列表
- confidence：high / medium / low

---

## IV. 根因验证技能

- 证据一致性检查器：验证假设与证据一致性
- 反证法：明确排除条件，有反证即排除
- 冲突消解器：当证据矛盾时，按置信度排序

### 验证类型

- validated：现有证据可直接判定
- excluded：有明确反证，已排除
- uncertain：证据不足，需补采

---

## V. 根因裁决技能

- 根因选定器：基于 validated_path 选定 Root Cause
- 层次分解器：分解为 Root Cause → Direct Cause → Trigger
- 置信度评估器：high / medium / low + 不确定性说明

---

## VI. 方案推导技能

- 方案生成器：基于根因生成 Top 3 候选方案
- 风险等级标签器：仅输出风险等级标签（low/medium/high）

---

## VII. 禁止项

- 禁止伪造、模拟、补充未真实采集的数据
- 禁止输出具体 risk_score 数值（仅输出风险等级标签）
- 禁止越权编排（sessions_spawn / sessions_yield）

---

## VIII. 版本变更记录

- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义
- **v0.3.0**（2026-04-23）：推理智能体技能清单
