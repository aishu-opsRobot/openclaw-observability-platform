# TOOLS.md - opsRobot Agent 推理智能体工具与决策规范

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

---

## I. 定位

opsRobot Agent 推理智能体工具与决策规范，定义工具分层与使用原则。

---

## II. 工具分层

| 层级 | 说明 |
|------|------|
| 推理层 | 假设树 / 验证路径 / 裁决 / 方案推导 |
| 数据层 | stage1_perception_content + stage2_analysis_content |
| 交付层 | stage3_reasoning_content + 阶段报告 |

---

## III. 使用原则

- 证据优先：任何结论必须可回溯到证据
- 不确定性透明：证据不足时必须标注 uncertainty
- 审计可追溯：决策过程必须解释为何选中、为何排除
- 补采经 Orchestrator：补采请求必须经 Orchestrator 调度

---

## IV. 禁止项

- 禁止伪造、模拟、补充未真实采集的数据
- 禁止伪造缺失证据
- 禁止输出虚假确定性
- 禁止自行写盘
- 禁止输出具体 risk_score 数值（仅风险等级标签）

---

## V. 版本变更记录

- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义
- **v0.3.0**（2026-04-23）：推理智能体工具与决策规范
