# SKILLS.md - opsRobot Agent 感知智能体技能清单

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

---

## I. 定位

opsRobot Agent 感知智能体技能清单，定义四项核心技能和数据采集规范。

---

## II. 技能概览

| 技能 | 说明 |
|------|------|
| 四类数据采集 | alerts / metrics / logs / traces |
| 时间窗治理 | 默认窗/扩窗/回溯窗管理 |
| 数据标准化 | 统一时间/单位/标签/实体标识 |
| 缺口识别 | 数据不可得的显式上报 |
| 充分性评估 | fact_sheet 完整度判定（sufficient/insufficient/failed）|
| 可视化数据生成 | stage1_metrics_trend / stage1_logs_distribution JSON |

---

## III. 数据采集技能

### 3.1 alerts 采集

- 查询端点：GET /api/v1/signals/alerts
- 必须参数：time_from / time_to
- 可选参数：severity, scenario, event_name, node, namespace, status, fuzzy, limit
- 返回字段：timestamp / type / event_name / event_severity / event_status / scenario / entity_object_name / ip
- 原始返回：必须展示查询命令 + 原始返回

### 3.2 metrics 采集

- 查询端点：GET /api/v1/signals/metrics
- 必须参数：time_from / time_to
- 可选参数：node, namespace, scenario, metric_name, pod, service, fuzzy, limit
- 返回字段：timestamp / values[] / metric.*（node_ip/namespace/pod/service/scenario/__name__）
- 原始返回：必须展示查询命令 + 原始返回

### 3.3 logs 采集

- 查询端点：GET /api/v1/signals/logs
- 必须参数：time_from / time_to
- 可选参数：level, severity, namespace, node, event, scenario, msg_contains, log_type, fuzzy, limit
- 返回字段：timestamp / labels.*（service/node/namespace/severity/scenario） / message.level
- 原始返回：必须展示查询命令 + 原始返回

### 3.4 traces 采集

- 查询端点：GET /api/v1/signals/traces
- 必须参数：time_from / time_to
- 可选参数：node, pod, service, scenario, operation, cluster, trace_id, fuzzy, limit
- 返回字段：trace_id / start_time / duration_ms / tags.*（service/node/namespace/scenario/error）
- 原始返回：必须展示查询命令 + 原始返回
- 限制：最大 2000 条（limit 上限）

---

## IV. 数据标准化技能

| 标准类型 | 说明 |
|----------|------|
| 时间统一 | Unix ms 或 ISO8601，带时区 |
| 单位统一 | SI制（秒/米/字节等）|
| 标签命名空间 | 统一小写 + 下划线 |
| 实体标识 | service/node/pod/namespace 完整路径 |

---

## V. 禁止项

- 禁止伪造数据
- 禁止模拟查询结果
- 禁止补写缺失字段
- 禁止调用写接口（/start / /stop / /resolve）
- 禁止越权编排（sessions_spawn / sessions_yield）

---

## VI. 版本变更记录

- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义；更新 JSON 文件命名
- **v2.0**（2026-05-01）：感知智能体技能清单
