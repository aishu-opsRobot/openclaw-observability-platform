# CONFIG.md - opsRobot Agent 感知智能体配置基线

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环
> **数据源:** chaosforge-query-ingest

---

## I. 定位

opsRobot Agent 感知智能体配置基线，定义数据源、查询参数、字段映射、运行策略、安全边界。

---

## II. 全局开关

- **data_ingest_enabled**
  - 默认值：`false`
  - 行为：仅保留流程连通测试，不发起真实采集
  - 设为 `true` 时：允许执行真实数据采集

---

## III. 数据源配置

**Base URL**：`$CHAOSFORGE_BASE_URL`（默认 `http://127.0.0.1:8777`）
**认证**：`$CHAOSFORGE_AUTH`（默认 `none`）

| 数据类型 | 查询端点 | 数据文件 |
|----------|----------|----------|
| alerts | GET /api/v1/signals/alerts | mock_events.jsonl |
| metrics | GET /api/v1/signals/metrics | mock_metrics.jsonl |
| logs | GET /api/v1/signals/logs | mock_logs.jsonl |
| traces | GET /api/v1/signals/traces | mock_traces.jsonl |

---

## IV. 查询参数参考

### 4.1 通用参数

| 参数 | 说明 |
|------|------|
| time_from / time_to | YYYY-MM-DD HH:MM:SS（必须）|
| fuzzy | true=模糊，false=精确（默认 true）|
| limit | 返回条数上限（默认 100，最大 5000）|

### 4.2 各数据类型特有参数

| 数据类型 | 特有参数 |
|----------|---------|
| alerts | severity, scenario, event_name, node, namespace, status |
| metrics | node, namespace, scenario, metric_name, pod, service |
| logs | level, severity, namespace, node, event, scenario, msg_contains, log_type |
| traces | node, pod, service, scenario, operation, cluster, trace_id |

---

## V. 字段标准化映射

| 标准字段 | alerts | metrics | logs | traces |
|----------|--------|---------|------|--------|
| timestamp | data.timestamp | data.values[] | labels.time | data.start_time |
| service | data.entity_object_name | data.metric.service | labels.service | data.tags.service |
| node | data.ip | data.metric.node_ip | labels.node | data.tags.node |
| namespace | data.entity_object_name | data.metric.namespace | labels.namespace | data.tags.namespace |
| severity | data.event_severity | — | labels.severity | — |
| scenario | data.scenario | data.metric.scenario | labels.scenario | data.tags.scenario |
| metric_name | — | data.metric.__name__ | — | — |
| level | — | — | message.level | — |
| trace_id | — | — | — | data.trace_id |
| duration_ms | — | — | — | data.duration_ms |
| error | — | — | — | data.tags.error |

---

## VI. 运行与降级策略

| 场景 | 处理方式 |
|------|---------|
| 单类数据失败 | 允许 partial，继续其余路径 |
| 多核心类失败 | 返回 failed 并上报 Orchestrator |
| 空结果 | 标记 data_gaps，不得伪造正常数据 |
| 超时/鉴权失败 | 记录 source_errors 并给出 retry_suggestion |
| 404 错误 | 不要重试，检查端点路径是否正确 |

---

## VII. 安全与边界

- **允许操作**：感知阶段只允许查询，不允许执行变更
- **禁止调用**：写接口（/start / /stop / /resolve）、适配器接口（/adapt/prometheus / /adapt/zabbix）
- **密钥管理**：禁止在配置中写入真实密钥（仅环境变量引用）
- **404 处理**：禁止在 404 时自动换成其他未知端点

---

## VIII. 环境变量

| 变量 | 默认值 |
|------|--------|
| DATA_INGEST_ENABLED | false |
| CHAOSFORGE_BASE_URL | http://127.0.0.1:8777 |
| CHAOSFORGE_AUTH | none |

---

## IX. 版本变更记录

- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义
- **v0.3.0**（2026-04-23）：感知智能体企业级配置基线
