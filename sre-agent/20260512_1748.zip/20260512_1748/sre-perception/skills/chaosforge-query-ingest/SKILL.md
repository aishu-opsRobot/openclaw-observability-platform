# chaosforge-query-ingest

## skill_id
`chaosforge-query-ingest`

## purpose
从 ChaosForge 查询四信号（告警/指标/日志/链路追踪）数据，仅限只读查询。

## source_type
`alert`

---

## 数据源信息

| 属性 | 值 |
|------|---|
| **Base URL** | `http://127.0.0.1:8777` |
| **认证** | `none`（默认无认证） |
| **数据文件** | `mock_events.jsonl` / `mock_metrics.jsonl` / `mock_logs.jsonl` / `mock_traces.jsonl` |

---

## inputs

| 字段 | 类型 | 必须性 | 说明 |
|------|------|--------|------|
| `query_type` | string | 必须 | `alerts \| metrics \| logs \| traces \| stats \| summary` |
| `scenario` | string | 可选 | 场景名称（模糊匹配） |
| `severity` | string | 可选 | 告警级别：High / Average / Warning / Information |
| `node` | string | 可选 | 节点 ID 或 IP（模糊匹配） |
| `namespace` | string | 可选 | 命名空间（模糊匹配） |
| `metric_name` | string | 可选 | 指标名称（模糊匹配） |
| `level` | string | 可选 | 日志级别（精确）：error / info / warning / critical |
| `operation` | string | 可选 | 操作名/Span 名（模糊匹配） |
| `trace_id` | string | 可选 | 精确 Trace ID（查单条调用链） |
| `time_from` | string | 可选 | 起始时间 YYYY-MM-DD HH:MM:SS |
| `time_to` | string | 可选 | 结束时间 YYYY-MM-DD HH:MM:SS |
| `fuzzy` | bool | 可选 | true=模糊匹配（默认），false=精确匹配 |
| `limit` | int | 可选 | 返回条数上限，默认 100，最大 5000（traces 最大 2000） |

---

## API 端点清单

| query_type | Method | Endpoint | 说明 |
|-------------|--------|----------|------|
| `signals_alerts` | GET | `/api/v1/signals/alerts` | 查询告警事件 |
| `signals_metrics` | GET | `/api/v1/signals/metrics` | 查询 Prometheus 指标 |
| `signals_logs` | GET | `/api/v1/signals/logs` | 查询结构化日志 |
| `signals_traces` | GET | `/api/v1/signals/traces` | 查询链路追踪 Span |
| `signals_stats` | GET | `/api/v1/signals/stats` | 聚合统计 |
| `signals_summary` | GET | `/api/v1/signals/summary` | 各信号类型总数 |

---

## 查询参数说明

### signals_alerts

| 参数 | 类型 | 说明 |
|------|------|------|
| `severity` | string | High / Average / Warning / Information |
| `scenario` | string | 场景名称（模糊） |
| `event_name` | string | 事件名称（模糊） |
| `node` | string | 节点 ID（模糊） |
| `namespace` | string | 命名空间（模糊） |
| `status` | string | firing / resolved |
| `time_from` | string | YYYY-MM-DD HH:MM:SS |
| `time_to` | string | YYYY-MM-DD HH:MM:SS |
| `fuzzy` | bool | true=模糊（默认），false=精确 |
| `limit` | int | 默认 100，最大 5000 |

### signals_metrics

| 参数 | 类型 | 说明 |
|------|------|------|
| `node` | string | 节点 ID（精确） |
| `namespace` | string | 命名空间（模糊） |
| `scenario` | string | 场景名称（模糊） |
| `metric_name` | string | 指标名称（模糊） |
| `pod` | string | Pod 名称（模糊） |
| `service` | string | Service 名称（模糊） |
| `time_from` | string | YYYY-MM-DD HH:MM:SS |
| `time_to` | string | YYYY-MM-DD HH:MM:SS |
| `fuzzy` | bool | true=模糊（默认），false=精确 |
| `limit` | int | 默认 100，最大 5000 |

### signals_logs

| 参数 | 类型 | 说明 |
|------|------|------|
| `level` | string | error / info / warning / critical（精确） |
| `severity` | string | 日志严重度（模糊） |
| `namespace` | string | 命名空间（模糊） |
| `node` | string | 节点 IP 或 ID（模糊） |
| `event` | string | 事件名称（模糊） |
| `scenario` | string | 场景名称（模糊） |
| `msg_contains` | string | 日志内容包含（模糊） |
| `log_type` | string | k8s_warning_event / fault_detail / kernel_log |
| `time_from` | string | YYYY-MM-DD HH:MM:SS |
| `time_to` | string | YYYY-MM-DD HH:MM:SS |
| `fuzzy` | bool | true=模糊（默认），false=精确 |
| `limit` | int | 默认 100，最大 5000 |

### signals_traces

| 参数 | 类型 | 说明 |
|------|------|------|
| `node` | string | 节点 IP 或 ID（模糊） |
| `pod` | string | Pod 名称（模糊） |
| `service` | string | Service 名称（模糊） |
| `scenario` | string | 场景名称（模糊） |
| `operation` | string | 操作名/Span 名（模糊） |
| `cluster` | string | 集群名称（模糊） |
| `trace_id` | string | 精确 Trace ID（查单条调用链） |
| `time_from` | string | YYYY-MM-DD HH:MM:SS |
| `time_to` | string | YYYY-MM-DD HH:MM:SS |
| `fuzzy` | bool | true=模糊（默认），false=精确 |
| `limit` | int | 默认 50，最大 2000 |

---

## 输出契约

### signals_* 标准响应

```json
{
  "source": "chaosforge-query-ingest",
  "query_type": "signals_alerts",
  "query": { "severity": "High", "scenario": "etcd_quorum_loss" },
  "total": 15,
  "records": [
    {
      "timestamp": "2026-04-18 17:28:52",
      "type": "alert",
      "event_name": "MySQL: Service is down",
      "event_severity": "High",
      "event_status": "发生",
      "scenario": "mariadb_full_cluster_crash",
      "entity_object_name": "k8s_cluster:ar_k8s_cluster_201,namespace:resource,name:proton-mariadb",
      "ip": "192.168.201.32"
    }
  ],
  "status": "success",
  "data_gaps": []
}
```

### signals_stats 响应结构

```json
{
  "source": "chaosforge-query-ingest",
  "query_type": "signals_stats",
  "alerts": {
    "by_severity": { "High": 12, "Average": 3 },
    "by_node": { "node-201-13": 3, "node-201-31": 2 },
    "by_scenario": { "etcd_quorum_loss": 15 }
  },
  "logs": {
    "by_level": { "error": 31, "critical": 19 },
    "by_type": { "k8s_warning_event": 31, "fault_detail": 31 },
    "by_namespace": { "kube-system": 8 }
  },
  "metrics": { "by_node": { "node-201-13": 13 } },
  "traces": { "span_count": 45, "trace_count": 15 }
}
```

---

## 调用示例

```bash
# 告警查询：High 级别 + etcd_quorum_loss 场景
web_fetch(url="http://127.0.0.1:8777/api/v1/signals/alerts?severity=High&scenario=etcd_quorum_loss&limit=10", extractMode="text")

# 指标查询：node-201-13 节点的所有指标
web_fetch(url="http://127.0.0.1:8777/api/v1/signals/metrics?node=node-201-13&limit=20", extractMode="text")

# 日志查询：error 级别
web_fetch(url="http://127.0.0.1:8777/api/v1/signals/logs?level=error&limit=20", extractMode="text")

# 链路查询：场景调用链
web_fetch(url="http://127.0.0.1:8777/api/v1/signals/traces?scenario=etcd_quorum_loss&limit=10", extractMode="text")

# 单条 Trace
web_fetch(url="http://127.0.0.1:8777/api/v1/signals/traces?trace_id=904d04b8a2ec457b", extractMode="text")

# 聚合统计
web_fetch(url="http://127.0.0.1:8777/api/v1/signals/stats?scenario=etcd_quorum_loss", extractMode="text")

# 总数汇总
web_fetch(url="http://127.0.0.1:8777/api/v1/signals/summary", extractMode="text")
```

---

## 错误处理

| HTTP Code | 含义 | 处理方式 |
|-----------|------|----------|
| 200 | 成功 | 解析 records |
| 401 | 认证失败 | 检查 auth_ref（当前为 none） |
| 404 | 端点不存在 | **不要重试**，检查 URL 路径 |
| 503 | 服务不可用 | 标记 `data_gaps`，继续其他数据源 |

### 404 常见原因

- ❌ 用了 `/api/v1/metrics`（正确：`/api/v1/signals/metrics`）
- ❌ 用了 `/api/v1/status`（ChaosForge 没有此端点）
- ❌ 端点拼写错误

---

## 禁止项

- 🚫 禁止调用写接口（`/start`、`/stop`、`/resolve`）
- 🚫 禁止调用适配器接口（`/adapt/prometheus`、`/adapt/zabbix`）
- 🚫 禁止在 404 时自动换成其他未知端点
- 🚫 禁止将四信号查询结果直接宣布为根因（感知 = Observe，非 Analysis）
- 🚫 禁止伪造采集结果
