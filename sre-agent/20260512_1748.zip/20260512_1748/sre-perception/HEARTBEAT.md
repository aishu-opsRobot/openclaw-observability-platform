# HEARTBEAT.md - opsRobot Agent 感知智能体心跳治理清单

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

---

## I. 定位

opsRobot Agent 感知智能体心跳治理清单，定义 Pipeline 心跳监控与巡检规范。

---

## II. 心跳机制

- 轻量巡检（每 30 分钟）：IDLE 时健康检查
- 故障高峰巡检（每 10 分钟）：PERCEPTION_IN_PROGRESS 时加速监控
- 事件驱动（按需）：Orchestrator 调用 / 数据采集完成 / 超时通知

---

## III. 超时阈值（快速索引）

| 子智能体 | 基础超时 | L1（×1.0）| L2（×1.5）| L3（×2.0）| L4（×3.0）| 上限 |
|---------|---------|---------|---------|---------|---------|------|
| sre-perception | 240s | 240s | 360s | 480s | 720s | 900s |

---

## IV. Stage 1 健康检查清单

- [ ] incident_id 格式正确
- [ ] 四类数据（alerts/metrics/logs/traces）已采集
- [ ] stage1_perception_content 完整度评估完成
- [ ] stage1_metrics_trend JSON 已生成
- [ ] stage1_logs_distribution JSON 已生成
- [ ] stage1_alerts_distribution JSON 已生成
- [ ] stage1_topology_map JSON 已生成
- [ ] stage1_trace_flamegraph JSON 已生成
- [ ] 阶段报告已生成
- [ ] 数据缺口已标注（如有）

---

## V. 版本变更记录

- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义；更新 JSON 文件命名
- **v2.0**（2026-05-01）：感知智能体心跳治理清单
