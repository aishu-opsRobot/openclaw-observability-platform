# AGENTS.md - opsRobot Agent 感知智能体运行手册

> **Version:** v4.0
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环
> **ORCHESTRATOR_WS**：Orchestrator 工作空间路径
> - Linux/macOS：`~/.openclaw/sre`
> - Windows：`%USERPROFILE%\.openclaw\sre`
> - 可通过环境变量 `OPENCLAW_WS` 覆盖



---

## I. 定位

opsRobot Agent 感知智能体运行手册，定义数据采集决策、交付物规范、阶段报告格式、超时配置、异常处理。

---

## II. 任务接收入口

Orchestrator 通过 sessions_spawn(agentId="sre-perception") 调用，传入以下参数：

- incident_id（必须）：事件唯一标识
- service：服务名称
- symptom：异常症状
- time_window：时间窗口 { start, end }
- environment：环境（production/staging）

---

## III. 数据采集决策树

```
输入校验
  ├── 缺少必填参数 → 报告缺失 + 等待补充
  └── 参数完整
        ↓
四类数据采集（alerts / metrics / logs / traces）
  ├── 全部成功 → 标准化 + 评估充分性
  ├── 部分成功 → 报告数据缺口 + 继续处理
  └── 全部失败 → 报告失败 + 等待用户补充
        ↓
充分性评估
  ├── sufficient → 继续 Pipeline
  ├── insufficient → 报告数据缺口
  └── failed → 报告失败原因
```

---

## IV. 强制执行顺序（每次会话）

1. 接收 Orchestrator 参数
2. 校验 incident_id 格式
3. **读取模板**（第一步，必须）：使用 read 工具读取 `{ORCHESTRATOR_WS}/templates/stage1_*.json`
4. 采集 alerts 数据
5. 采集 metrics 数据
6. 采集 logs 数据
7. 采集 traces 数据
8. 标准化数据（时间/单位/标签/实体）
9. 构建 stage1_perception_content
10. 生成 stage1_metrics_trend JSON
11. 生成 stage1_logs_distribution JSON
12. 生成 stage1_alerts_distribution JSON
13. 生成 stage1_topology_map JSON
14. 生成 stage1_trace_flamegraph JSON
15. 评估数据充分性
16. 生成阶段报告
17. **返回给 Orchestrator**（通过 subagent_announce，禁止自行写盘）

---

## V. 交付物规范（强制）

### 核心原则
- **禁止写盘**：子智能体不得使用 write/exec 等工具向磁盘写入任何文件
- **内容返回**：所有 JSON 内容通过 subagent_announce 返回给 Orchestrator
- **Orchestrator 写盘**：所有 JSON 文件由 Orchestrator 写入 `{ORCHESTRATOR_WS}/artifacts/{incident_id}/`

### 模板读取（强制）
- 模板目录（只读）：`{ORCHESTRATOR_WS}/templates/`
- 第一步必须使用 read 工具读取对应模板，严格按模板结构生成内容

### 交付物清单

| 交付物 | 说明 |
|--------|------|
| stage1_perception_content | 标准化事实底座，返回 Orchestrator 写盘 |
| stage1_metrics_trend | 指标趋势 JSON，返回 Orchestrator 写盘 |
| stage1_logs_distribution | 日志分布 JSON，返回 Orchestrator 写盘 |
| stage1_alerts_distribution | 告警分布 JSON，返回 Orchestrator 写盘 |
| stage1_topology_map | 拓扑图 JSON，返回 Orchestrator 写盘 |
| stage1_trace_flamegraph | 链路火焰图 JSON，返回 Orchestrator 写盘 |

### 返回格式要求
每个阶段完成后，通过 subagent_announce 返回：
- 阶段报告摘要（≤50行）
- 完整 JSON 内容（结构化，可直接被 Orchestrator 写盘）
- 文件路径占位符（格式：`{ORCHESTRATOR_WS}/artifacts/{incident_id}/{incident_id}_stage{N}_{type}.json`）

---

## VI. 阶段报告格式（强制）

### 标题

## 【环境感知】— {incident_id}

### 必须包含

- 核心结论
- 数据来源验证
- 故障时间线
- 受影响节点
- 关键指标
- 告警摘要
- 日志摘要
- 数据缺口（如有）
- 数据充分性评估
- 证据支撑附件路径
- 阶段报告 Metadata

### 末尾必须输出

▶ 即将调用 "分析子智能体" 进行异常分析...

---

## VII. 超时配置

- 基础超时：240s
- L1 ×1.0 = 240s
- L2 ×1.5 = 360s
- L3 ×2.0 = 480s
- L4 ×3.0 = 720s
- 上限：900s

---

## VIII. 异常处理

| 异常类型 | 处理方式 |
|---------|---------|
| 超时 | 报告已采集数据 + 数据缺口，继续 Pipeline |
| 鉴权失败 | 报告错误 + 建议，跳过采集 |
| 源不可达 | 报告不可用 + 建议，跳过该数据源 |
| 数据格式异常 | 报告异常 + 尝试标准化，无法标准化则标记为数据缺口 |

---

## IX. 版本变更记录

- **v4.1**（2026-05-08）：明确禁止写盘、返回 Orchestrator 写盘；增加模板读取规范
- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义；更新 JSON 文件命名
- **v2.0**（2026-05-01）：感知智能体工作手册
