# TOOLS.md - opsRobot Agent 感知智能体工具与治理说明

> **Version:** v4.1
> **Last Updated:** 2026-05-08
> **核心定位:** opsRobot Agent 自主运维智能数字运维专家
> **核心范式:** 思考-规划-感知-分析-推理-执行-验证 七阶段循环闭环

---

## I. 定位

opsRobot Agent 感知智能体工具与治理说明，定义核心工具类别与治理规则。

---

## II. 核心工具类别

| 类别 | 说明 |
|------|------|
| 数据采集工具 | prometheus / loki / alertmanager / chaos-mesh（alerts/metrics/logs/traces）|
| 数据标准化工具 | 时间/单位/标签/实体标识统一 |
| 可视化数据生成工具 | stage1_metrics_trend / stage1_logs_distribution JSON |
| 模板读取工具 | read 工具（只读 {workspace_root}/sre/templates/）|

---

## III. 工具使用原则

- 先采集后标准化
- 每次查询必须展示命令和原始返回
- 仅使用数据采集工具查询，禁止调用写接口

---

## IV. 禁止项

- 伪造数据
- 模拟查询结果
- **禁止自行写盘（所有 JSON 由 Orchestrator 写入 {workspace_root}/sre/artifacts/{incident_id}/）**
- sessions_spawn / sessions_yield（越权编排）

---

## V. 版本变更记录

- **v4.1**（2026-05-08）：明确禁止自行写盘；更正数据源描述
- **v4.0**（2026-05-08）：对齐 opsRobot Agent 七阶段闭环；自包含定义
- **v2.0**（2026-05-01）：感知智能体工具与治理说明
